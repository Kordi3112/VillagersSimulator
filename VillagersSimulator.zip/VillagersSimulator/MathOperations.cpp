#include "MathOperations.h"

bool MathOperations::areTwoRectanglesConnected(sf::Vector2f coord11, sf::Vector2f coord12, sf::Vector2f coord21, sf::Vector2f coord22)
{
	// If one rectangle is on left side of other 
	if (coord11.x > coord22.x || coord12.x > coord21.x)
        return false; 
  
    // If one rectangle is above other 
    if (coord11.y < coord22.y || coord12.y < coord21.y)
        return false; 
  
    return true; 
}

bool MathOperations::areTwoRectanglesConnected(sf::Vector2f coord11, sf::Vector2f coord12, sf::Vector2f cameraPos, sf::Rect<float> viewPort, sf::Vector2u screenSize, float zoom)
{
	return MathOperations::areTwoRectanglesConnected(coord11, coord12, cameraPos - sf::Vector2f(viewPort.width * screenSize.x, viewPort.height * screenSize.y) / (2.f * zoom), cameraPos + sf::Vector2f(viewPort.width * screenSize.x, viewPort.height * screenSize.y) / (2.f * zoom));
}


