#pragma once
class Mother
{
public:
	Mother();
	~Mother();
};

