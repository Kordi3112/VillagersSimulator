#pragma once
class Building
{
public:
	Building();
	~Building();
};

