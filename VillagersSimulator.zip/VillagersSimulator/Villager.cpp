#include "Villager.h"



Villager::Villager()
{
}


Villager::~Villager()
{
}
