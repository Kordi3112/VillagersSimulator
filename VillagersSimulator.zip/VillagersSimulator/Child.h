#pragma once
class Child
{
public:
	Child();
	~Child();
};

