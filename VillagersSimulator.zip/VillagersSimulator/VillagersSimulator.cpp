#include <SFML/Graphics.hpp>
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <iostream>
#include <time.h>
#include <thread>
#include "MainEngine.h"

#pragma comment(lib,"sfml-graphics-d.lib")
#pragma comment(lib,"sfml-audio-d.lib")
#pragma comment(lib,"sfml-network-d.lib")
#pragma comment(lib,"sfml-window-d.lib")
#pragma comment(lib,"sfml-system-d.lib")


void ThreadFunction()
{
	//Sleep(500);
	for (;;)
	{
		sf::sleep(sf::milliseconds(1000));
		std::cout << "Thread" << std::endl;
	}
	
}

int main()
{
	//JUNKS
	sf::Vector2f cameraPos = sf::Vector2f(GetSystemMetrics(SM_CXSCREEN)/2.0f, GetSystemMetrics(SM_CYSCREEN) );
	int FPS = 0;
	float g_zoom=1.f;
	sf::Clock minute;
	//
	///----CLOCKS
	sf::Clock frameTimeClock;
	///
	sf::ContextSettings contextSettings;
	//setting antialising to 8
	contextSettings.antialiasingLevel = 8;
	//creating window
	//sf::RenderWindow hWindow(sf::VideoMode(1080, 720, 32), "VillagersSimulator", sf::Style::Default, contextSettings);
	sf::RenderWindow hWindow(sf::VideoMode(GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), 32), "VillagersSimulator", sf::Style::Fullscreen, contextSettings);

	//MainEngine Init
	MainEngine* hMainEngine = new MainEngine();//handle to MainEngine 

	hMainEngine->setViewPort(sf::Rect<float>(0.1f, 0.1f, 0.8f, 0.5f));

	//Thread
	sf::Thread thread(&MainEngine::ThreadFunction, hMainEngine);
	thread.launch();
	//
	Terrain terrain;
	terrain.generateMap(time(NULL));
	terrain.refreshAllChunksTexture();
	//std::cout << (int)sf::Color::Green.b << std::endl;
	//
	minute.restart();
	frameTimeClock.restart();
	//
	while (hWindow.isOpen())
	{
		///------------EVENTS
		sf::Event event;
		while (hWindow.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
			{
				hWindow.close();
			}
			if (event.type == sf::Event::KeyPressed)
			{
				if (event.key.code == sf::Keyboard::Escape)hWindow.close();
				//
				if (event.key.code == sf::Keyboard::W)g_zoom *= 2;
				if (event.key.code == sf::Keyboard::S)g_zoom /= 2;
				

			}
		}
		///--------------REFRESH COTROLERS
		int refreshTimeUs = frameTimeClock.getElapsedTime().asMicroseconds();
		frameTimeClock.restart();
		float splitSecond = refreshTimeUs / 1000000.0f;
		//
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))cameraPos.x -= 200 * splitSecond;
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))cameraPos.x += 200 * splitSecond;
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))cameraPos.y -= 200 * splitSecond;
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))cameraPos.y += 200 * splitSecond;

		///
		///---------RENDER
		hWindow.clear();
		//
		hMainEngine->draw(hWindow);
		terrain.renderChunks(hWindow, cameraPos, sf::Rect<float>(0.05f, 0.05f, 0.9f, 0.9f), g_zoom);
		//
		hWindow.display();
		FPS++;
		//
		if (minute.getElapsedTime().asMilliseconds() >= 1000)
		{
			
			std::cout << FPS << std::endl;
			minute.restart();
			FPS = 0;
		}
	}
	//delete thread
	thread.terminate();
	//clean memory
	terrain.releaseChunks();
	delete hMainEngine;
	//
	return 0;
}