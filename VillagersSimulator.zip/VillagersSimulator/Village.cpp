#include "Village.h"



Village::Village()
{
}


Village::~Village()
{
}
