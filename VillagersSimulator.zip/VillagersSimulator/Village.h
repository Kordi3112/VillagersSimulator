#pragma once
class Village
{
public:
	Village();
	~Village();
};

