#include "Building.h"



Building::Building()
{
}


Building::~Building()
{
}
