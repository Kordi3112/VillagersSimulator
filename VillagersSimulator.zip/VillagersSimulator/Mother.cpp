#include "Mother.h"



Mother::Mother()
{
}


Mother::~Mother()
{
}
