#pragma once
class Villager
{
public:
	Villager();
	~Villager();
};

